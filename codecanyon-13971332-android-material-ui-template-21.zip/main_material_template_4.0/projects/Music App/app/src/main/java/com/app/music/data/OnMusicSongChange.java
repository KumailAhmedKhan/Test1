package com.app.music.data;

import com.app.music.model.MusicSong;

public interface OnMusicSongChange {

    void onChange(MusicSong musicSong);

}
