package com.app.music.model;

import java.io.Serializable;

public class Artist implements Serializable {

    public int image;
    public String title;
    public String brief;

}
