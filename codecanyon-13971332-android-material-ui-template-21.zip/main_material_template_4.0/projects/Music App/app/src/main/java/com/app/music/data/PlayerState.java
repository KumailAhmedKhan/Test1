package com.app.music.data;

public enum PlayerState {

    START,
    PAUSE,
    RESTART

}
