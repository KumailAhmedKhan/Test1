package com.app.music.model;

import java.io.Serializable;

public class MusicAlbum implements Serializable {

    public int id;
    public int image;
    public String name;
    public String brief;
    public int color;


}
