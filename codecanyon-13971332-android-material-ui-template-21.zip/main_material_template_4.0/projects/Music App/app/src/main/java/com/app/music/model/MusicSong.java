package com.app.music.model;

import java.io.Serializable;

public class MusicSong implements Serializable {

    public int image;
    public String title;
    public String album;
    public int album_id;

}
